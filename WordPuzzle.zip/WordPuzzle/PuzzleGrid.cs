﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordPuzzle
{
    public class PuzzleGrid
    {
        private readonly char[][][] letterGrid;
        private readonly Trie rootTrie;

        private int MinX { get { return 0; } }
        private int MinY { get { return 0; } }
        private int MinZ { get { return 0; } }

        private int MaxX { get { return letterGrid[0][0].Length - 1; } }
        private int MaxY { get { return letterGrid[0].Length - 1; } }
        private int MaxZ { get { return letterGrid.Length - 1; } }

        private readonly List<Point> direction = new List<Point>
            {
                new Point(-1, -1, -1), new Point(0, -1, -1), new Point(1, -1, -1),
                new Point(-1, 0, -1),  new Point(0, 0, -1),  new Point(1, 0, -1),
                new Point(-1, 1, -1),  new Point(0, 1, -1),  new Point(1, 1, -1),

                new Point(-1, -1, 0),  new Point(0, -1, 0),  new Point(1, -1, 0),
                new Point(-1, 0, 0),                         new Point(1, 0, 0),
                new Point(-1, 1, 0),   new Point(0, 1, 0),   new Point(1, 1, 0),

                new Point(-1, -1, 1),  new Point(0, -1, 1),  new Point(1, -1, 1),
                new Point(-1, 0, 1),   new Point(0, 0, 1),   new Point(1, 0, 1),
                new Point(-1, 1, 1),   new Point(0, 1, 1),   new Point(1, 1, 1),
            };

        public PuzzleGrid(IEnumerable<string> words)
        {
            rootTrie = Trie.BuildTrie(words);
            letterGrid = GenerateLettergrid();
        }

        public IEnumerable<string> FindWords()
        {
            var foundWords = new ConcurrentBag<string>();

            Parallel.For(0, MaxZ + 1, z =>
                Parallel.For(0, MaxY + 1, y =>
                    Parallel.For(0, MaxX + 1, x =>
                        FindWordsFromPoint(foundWords, new HashSet<Point>(), new Point(x, y, z), ""))));

            return foundWords.Distinct();
        }

        private void FindWordsFromPoint(ConcurrentBag<string> foundWords, HashSet<Point> visitedPoints, Point currentPoint, string prefix)
        {
            string currentPrefix = prefix + letterGrid[currentPoint.Z][currentPoint.Y][currentPoint.X];
            //int index = currentPrefix.findIndex(currentPrefix);
            if (!rootTrie.ContainsPrefix(currentPrefix))
            {
                return;
            }

            if (rootTrie.ContainsWord(currentPrefix))
            {
                foundWords.Add(currentPrefix);
            }

            visitedPoints.Add(currentPoint);

            foreach (var offset in direction)
            {
                int newX = currentPoint.X + offset.X;
                int newY = currentPoint.Y + offset.Y;
                int newZ = currentPoint.Z + offset.Z;

                if (newX.IsBetweenInclusive(MinX, MaxX) && newY.IsBetweenInclusive(MinY, MaxY) && newZ.IsBetweenInclusive(MinZ, MaxZ))
                {
                    var nextPoint = new Point(newX, newY, newZ);
                    if (!visitedPoints.Contains(nextPoint))
                    {
                        FindWordsFromPoint(foundWords, visitedPoints, nextPoint, currentPrefix);
                    }
                }
            }

            visitedPoints.Remove(currentPoint);
        }

        private char[][][] GenerateLettergrid()
        {
            return new char[][][]
                {
                    new char[][]
                        {
                            new char[] { 'a', 'b', 'c', 'd', 'e' },
                            new char[] { 'f', 'g', 'h', 'i', 'j' },
                            new char[] { 'k', 'l', 'm', 'n', 'o' },
                            new char[] { 'p', 'q', 'r', 's', 't' },
                            new char[] { 'u', 'v', 'w', 'x', 'y' }
                     },

             };
        }

        public string GetLetterGrid()
        {
            var sb = new StringBuilder();

            foreach (char[][] plane in letterGrid)
            {
                foreach (char[] row in plane)
                {
                    foreach (char c in row)
                    {
                        sb.Append(c + " ");
                    }
                    sb.AppendLine();
                }
                sb.AppendLine();
            }

            return sb.ToString();
        }

    }
}