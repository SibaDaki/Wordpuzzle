﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace WordPuzzle
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] wordslist = File.ReadAllLines("wordlist.txt");

            var solver = new PuzzleGrid(wordslist);

            Console.WriteLine("Letter Grid:");
            Console.WriteLine(solver.GetLetterGrid());

            
            var foundWords = solver.FindWords().ToList();
            Array.IndexOf(wordslist, foundWords);
          
            Console.WriteLine("The following Words were found on the grid" );
           
            Console.WriteLine(string.Join(Environment.NewLine, foundWords));
           // Console.WriteLine(string.Join(Environment.NewLine, "{0}", foundWords));
            Console.ReadKey();
            
        }
    }
}
