﻿using System;

namespace WordPuzzle
{
    public static class Compare
    {
        public static bool IsBetweenInclusive<T>(this T val, T min, T max) where T : IComparable<T>
        {
            return val.CompareTo(min) >= 0 && val.CompareTo(max) <= 0;
        }
    }
}